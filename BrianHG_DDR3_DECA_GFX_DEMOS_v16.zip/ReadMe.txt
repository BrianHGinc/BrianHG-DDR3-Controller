Release V1.6 Demo .sof programming files of DECA BrianHG_DDR3_Controller v1.6 and multi-window BrianHG_GFX_VGA_Window_System v1.6 for Arrow DECA eval board.

  >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D
  >:D  500MHz/1GTPS! with 2x32bit 1080p60 video layers.      >:D
  >:D  That's >1100 megabytes/sec just to show the image,    >:D
  >:D  never mind simultaneously drawing all those ellipses. >:D
  >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D >:D

Just open your JTAG programmer and add one of the following 2 files:
1. 'BrianHG_DDR3_DECA_GFX_DEMO_v16_1_LAYER_500MHzQR.sof'
        -> Replaces and replicates the original Ellipse Generator now using the new BrianHG_GFX_VGA_Window_System.

2. 'BrianHG_DDR3_DECA_GFX_DEMO_v16_2_LAYERS_500MHzQR.sof'
        -> Improved original Ellipse Generator demo where a second translucent superimposed video window scrolls at different coordinates and speeds generating an LSD trip visual effect.  (Note that the scroll switch needs to be turned on long enough at least bounce off 1 window edge to view effect.)

Check-on the 'Program/Configure' and click 'Start' to program.
The DECA's HDMI should output a 1080p image.


IMPORTANT NOTE:
If the picture is still or scrolling noise, just press buttons 0 or 1, or flip 'Switch 0' to enable drawing ellipses.  You just powered up the demo in frozen picture mode and you are looking at the powered up random blank memory.

Switch 0 = Enable/Disable drawing of ellipses.
Switch 1 = Enable/Disable screen scrolling.
Button 0 = Draw data from random noise generator.
Button 1 = Draw color image data from a binary counter.

Full Github v1.6 source code coming this weekend.
https://github.com/BrianHGinc/BrianHG-DDR3-Controller
