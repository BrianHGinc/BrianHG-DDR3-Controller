Arrow DECA BrianHG_DDR3_Controller V1.5 overclocked to 500MHz in Half-rate mode.
https://github.com/BrianHGinc/BrianHG-DDR3-Controller

 *****************************************************
 *** 500MHz/1GTPS! with 250MHz multiport interface ***
 *****************************************************

Just open your JTAG programmer and add one of the following 3 files:
1. 'BrianHG_DDR3_DECA_500MHz_DDR3_v1.0_QR_GFX_1080p_v3.sof'        -> DDR3_V1.0, 500MHz DDR_CK, Quarter Rate 125MHz Multiport & Ellipse Generator.
2. 'BrianHG_DDR3_DECA_400MHz_DDR3_V1.5_HR_GFX_1080p_v3.sof'        -> DDR3_V1.5, 400MHz DDR_CK, Half    Rate 200MHz Multiport & Ellipse Generator.
3. 'BrianHG_DDR3_DECA_500MHz_DDR3_V1.5_HR_GFX_1080p_NOELLIPSE.sof' -> DDR3_V1.5, 500MHz DDR_CK, Half    Rate 250MHz Multiport & Random noise/Binary counter.

Note that the Ellipse generator function has a <200MHz bottleneck, so with demo programming file 3, only pressing buttons 0 or 1 will illustrate the DDR3 32 bit color 250MHz fill speed with random noise or the binary counter pattern.

Check-on the 'Program/Configure' and click 'Start' to program.
The DECA's HDMI should output a 1080p image.

IMPORTANT NOTE:
If the picture is still or scrolling noise, just press buttons 0 or 1, or flip 'Switch 0' to enable drawing ellipses.
You just powered up the demo in frozen picture mode and you are looking at the powered up random blank memory.

Switch 0 = Enable/Disable drawing of ellipses.
Switch 1 = Enable/Disable screen scrolling.
Button 0 = Draw data from random noise generator.
Button 1 = Draw color image data from a binary counter.
