Arrow DECA BrianHG_DDR3_Controller overclocked to 500MHz.
https://github.com/BrianHGinc/BrianHG-DDR3-Controller

 *********************
 *** 500MHz/1GTPS! ***
 *********************

Just open your JTAG programmer and add the 'BrianHG_DDR3_DECA_500MHz_DDR3_GFX_1080p_v3.sof' programming file.


IMPORTANT NOTE:
If the picture is still or scrolling noise, just flip 'Switch 0'.
You just powered up the demo in frozen picture mode and you are looking at the powered up random blank memory.


Switch 0 = Enable/Disable drawing of ellipses.
Switch 1 = Enable/Disable screen scrolling.
Button 0 = Draw data from random noise generator.
Button 1 = Draw color image data from a binary counter.
